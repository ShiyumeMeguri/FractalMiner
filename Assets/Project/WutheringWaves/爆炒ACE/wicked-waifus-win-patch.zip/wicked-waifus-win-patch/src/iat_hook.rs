// src/iat_hook.rs
#![allow(non_snake_case)]
#![allow(non_camel_case_types)]

use backtrace::Backtrace;
use std::fs::{OpenOptions, read_to_string};            // ← 新增 read_to_string
use std::io::Write;
use std::ptr;
use std::sync::{Mutex, OnceLock};
use std::thread;
use std::time::Duration;

#[cfg(target_arch = "x86_64")]
use winapi::um::{
    processthreadsapi::ExitThread,
    winnt::CONTEXT,
};

/* ---------- Win32 Vectored-Exception FFI ---------- */

#[repr(C)]
struct EXCEPTION_RECORD {
    ExceptionCode: u32,
    ExceptionFlags: u32,
    ExceptionRecord: *mut EXCEPTION_RECORD,
    ExceptionAddress: *mut core::ffi::c_void,
    NumberParameters: u32,
    ExceptionInformation: [usize; 15],
}

#[repr(C)]
struct EXCEPTION_POINTERS {
    ExceptionRecord: *mut EXCEPTION_RECORD,
    ContextRecord: *mut core::ffi::c_void,
}

type PVECTORED_EXCEPTION_HANDLER =
    Option<unsafe extern "system" fn(*mut EXCEPTION_POINTERS) -> i32>;

unsafe extern "system" {
    fn AddVectoredExceptionHandler(
        FirstHandler: u32,
        Handler: PVECTORED_EXCEPTION_HANDLER,
    ) -> *mut core::ffi::c_void;
    fn RemoveVectoredExceptionHandler(handle: *mut core::ffi::c_void) -> u32;
}

/* ---------- 实际逻辑 ---------- */

const IAT_BASE: usize = 0x1468_6400_0;
const IAT_SIZE: usize = 0x2480;
const EXCEPTION_CONTINUE_EXECUTION: i32 = -1;          // ← 新增常量

static LOG_FILE: OnceLock<Mutex<std::fs::File>> = OnceLock::new();

/* 线程退出桩 */
unsafe extern "system" fn terminate_current_thread() -> ! {
    unsafe { ExitThread(0) };
    std::hint::unreachable_unchecked()
}

unsafe extern "system" fn veh_handler(info: *mut EXCEPTION_POINTERS) -> i32 {
    let bt = Backtrace::new();
    let msg = format!(
        "Crash at {:p}\nBacktrace:\n{:?}\n\n",
        (*(*info).ExceptionRecord).ExceptionAddress,
        bt
    );
    print!("{msg}");
    if let Some(f) = LOG_FILE.get() {
        let _ = f.lock().unwrap().write_all(msg.as_bytes());
    }

    #[cfg(target_arch = "x86_64")]
    {
        let ctx = &mut *(*info).ContextRecord.cast::<CONTEXT>();
        ctx.Rip = terminate_current_thread as usize as u64;
    }

    EXCEPTION_CONTINUE_EXECUTION
}

pub(crate) unsafe fn enumerate_and_call_iat() {
    let file = OpenOptions::new()
        .create(true)
        .append(true)
        .open("iatlogo.txt")
        .unwrap();
    let _ = LOG_FILE.set(Mutex::new(file));

    /* ----- 读取 cg.txt 获取偏移 ----- */
    let offset = read_to_string("cg.txt")
        .ok()
        .and_then(|s| {
            let s = s.trim();
            if s.is_empty() {
                None
            } else if let Some(hex) = s.strip_prefix("0x").or_else(|| s.strip_prefix("0X")) {
                usize::from_str_radix(hex, 16).ok()
            } else {
                s.parse::<usize>().ok()
            }
        })
        .unwrap_or(0);

    /* ----- 修正遍历范围，避免越界 ----- */
    let available_bytes = IAT_SIZE.saturating_sub(offset);
    if available_bytes == 0 {
        return;                                         // 无可用条目，直接结束
    }
    println!("快附加 Attach me!");
    thread::sleep(Duration::from_secs(1));

    let veh = AddVectoredExceptionHandler(1, Some(veh_handler));

    let entry_count = available_bytes / std::mem::size_of::<usize>();
    let iat = (IAT_BASE + offset) as *const usize;

    for idx in 0..entry_count {
        let fn_ptr = ptr::read(iat.add(idx));
        if fn_ptr == 0 {
            continue;
        }

        let _ = thread::Builder::new()
            .name(format!("iat_{idx}"))
            .spawn(move || unsafe {
                // 同步打印到控制台
                let off = offset + idx * std::mem::size_of::<usize>();
                println!("IAT call at 0x{:x}+0x{:x}", IAT_BASE + offset, off);
                let f: extern "system" fn() = std::mem::transmute(fn_ptr);
                let _ = std::panic::catch_unwind(|| f());
            });

        thread::sleep(Duration::from_millis(100));
    }

    thread::sleep(Duration::from_secs(1));
    RemoveVectoredExceptionHandler(veh);
}
