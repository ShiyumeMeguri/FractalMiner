# wicked-waifus-win-patch

PAK files signature check bypass for the PC version of a certain game.

### How to use
Just inject it at early startup.

#### Need help?
Consider joining our [discord server](https://discord.gg/reversedrooms)

